﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Dynamic : MonoBehaviour
{
    public float Speed;
    public float JumpPower;
    public bool isJump = false;

    public int Score = 0;

    // Start is called before the first frame update
    void Start()
    {
        //transform.position += Vector3.right;
    }

    // Update is called once per frame
    void Update()
    {
        //왼쪽, 위,아래 모두 추가하기
        if (Input.GetKey(KeyCode.RightArrow))
            transform.position += Vector3.right * Speed * Time.deltaTime;
        if (Input.GetKey(KeyCode.LeftArrow))
            transform.position += Vector3.left * Speed * Time.deltaTime;
        
        if (Input.GetKeyDown(KeyCode.Space))
        {
            if (isJump == false)
            {
                Rigidbody2D rigidbody = GetComponent<Rigidbody2D>();
                rigidbody.AddForce(Vector3.up * JumpPower);
                isJump = true;
                //transform.position += Vector3.up * JumpPower * Time.deltaTime;
            }
        }
        
        if (Input.GetKey(KeyCode.DownArrow))
            transform.position += Vector3.down * Speed * Time.deltaTime;
    }

    private void OnGUI()
    {
        GUI.Box(new Rect(0, 0, 100, 20), "Score:" + Score);
    }

    //private void OnTriggerEnter2D(Collider2D collision)
    //{
    //    //if (collision.gameObject.name == "cherry")
    //    if (collision.gameObject.tag == "Item")
    //    {
    //        Score++;
    //        Destroy(collision.gameObject);
    //    }
    //}
    //트리거스테이는 매프레임마다 발생하지않으므로 주의해서 사용할것!
    private void OnTriggerStay2D(Collider2D collision)
    {
        if(collision.gameObject.name == "Ladder")
        {
            if (Input.GetKey(KeyCode.UpArrow))
                transform.position += Vector3.up * Speed * Time.deltaTime;
            if (Input.GetKey(KeyCode.DownArrow))
                transform.position += Vector3.down * Speed * Time.deltaTime;
            Rigidbody2D rigidbody = GetComponent<Rigidbody2D>();
            rigidbody.gravityScale = 0;
            rigidbody.velocity = Vector2.zero;
        }
        Debug.Log("OnTriggerStay2D:" + collision.gameObject.name);
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.name == "Ladder")
        {
            Rigidbody2D rigidbody = GetComponent<Rigidbody2D>();
            rigidbody.gravityScale = 1;
            rigidbody.velocity = Vector2.zero;
        }
        Debug.Log("OnTriggerExit2D:" + collision.gameObject.name);
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        isJump = false;
      
        Debug.Log("OnCollisionEnter2D:" + collision.gameObject.name);
    }

    private void OnCollisionExit2D(Collision2D collision)
    {
        //isJump = true; //땅에서 나갔다고 해서 점프인가?
        Debug.Log("OnCollisionExit2D:" + collision.gameObject.name);
    }
}
